-- ════════════════════════════════════════════════════════════════
-- SUBSTOX — Supabase Database Setup
-- Run this entire file in: Supabase Dashboard → SQL Editor → Run
-- ════════════════════════════════════════════════════════════════


-- ── 1. SKUS ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS skus (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  sku_code          text NOT NULL,
  name              text NOT NULL,
  category          text,
  current_stock     integer DEFAULT 0,
  reorder_point     integer DEFAULT 0,
  lead_time_days    integer DEFAULT 14,
  unit_price        numeric(10,2) DEFAULT 0,
  unit_cost         numeric(10,2) DEFAULT 0,
  safety_stock      integer DEFAULT 0,
  annual_demand     integer DEFAULT 0,
  ordering_cost     numeric(10,2) DEFAULT 50,
  bin_location      text,
  status            text DEFAULT 'unknown',
  days_of_stock     integer DEFAULT 0,
  abc_class         text DEFAULT 'C',
  notes             text,
  created_at        timestamptz DEFAULT now(),
  updated_at        timestamptz DEFAULT now()
);

-- ── 2. INVENTORY LOTS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS inventory_lots (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  sku_id              uuid REFERENCES skus(id) ON DELETE CASCADE,
  sku_name            text,
  lot_number          text NOT NULL,
  received_date       date NOT NULL,
  expiry_date         date,
  quantity_received   integer DEFAULT 0,
  quantity_remaining  integer DEFAULT 0,
  unit_cost           numeric(10,2) DEFAULT 0,
  notes               text,
  created_at          timestamptz DEFAULT now()
);

-- ── 3. PURCHASE ORDERS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS purchase_orders (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  sku_name        text,
  supplier_name   text,
  quantity        integer DEFAULT 0,
  unit_cost       numeric(10,2) DEFAULT 0,
  total_cost      numeric(10,2) DEFAULT 0,
  status          text DEFAULT 'DRAFT',
  expected_date   date,
  notes           text,
  created_at      timestamptz DEFAULT now(),
  updated_at      timestamptz DEFAULT now()
);

-- ── 4. SUPPLIERS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS suppliers (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name            text NOT NULL,
  email           text,
  lead_time_days  integer DEFAULT 14,
  on_time_rate    numeric(5,2) DEFAULT 90,
  fill_rate       numeric(5,2) DEFAULT 95,
  payment_terms   text DEFAULT 'Net 30',
  notes           text,
  created_at      timestamptz DEFAULT now()
);

-- ── 5. ALERTS ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS alerts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title       text NOT NULL,
  description text,
  severity    text DEFAULT 'MEDIUM',
  is_read     boolean DEFAULT false,
  sku_name    text,
  category    text,
  action_page text,
  created_at  timestamptz DEFAULT now()
);


-- ════════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- Users can ONLY see and edit their own data. Critical for SaaS.
-- ════════════════════════════════════════════════════════════════

ALTER TABLE skus             ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_lots   ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_orders  ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers        ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts           ENABLE ROW LEVEL SECURITY;

-- SKUs policies
CREATE POLICY "Users see own skus"    ON skus FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own skus" ON skus FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own skus" ON skus FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own skus" ON skus FOR DELETE USING (auth.uid() = user_id);

-- Lots policies
CREATE POLICY "Users see own lots"    ON inventory_lots FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own lots" ON inventory_lots FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own lots" ON inventory_lots FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own lots" ON inventory_lots FOR DELETE USING (auth.uid() = user_id);

-- POs policies
CREATE POLICY "Users see own pos"    ON purchase_orders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own pos" ON purchase_orders FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own pos" ON purchase_orders FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own pos" ON purchase_orders FOR DELETE USING (auth.uid() = user_id);

-- Suppliers policies
CREATE POLICY "Users see own suppliers"    ON suppliers FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own suppliers" ON suppliers FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own suppliers" ON suppliers FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own suppliers" ON suppliers FOR DELETE USING (auth.uid() = user_id);

-- Alerts policies
CREATE POLICY "Users see own alerts"    ON alerts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own alerts" ON alerts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own alerts" ON alerts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own alerts" ON alerts FOR DELETE USING (auth.uid() = user_id);


-- ════════════════════════════════════════════════════════════════
-- AUTO-UPDATE updated_at TIMESTAMPS
-- ════════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER skus_updated_at
  BEFORE UPDATE ON skus
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER pos_updated_at
  BEFORE UPDATE ON purchase_orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ════════════════════════════════════════════════════════════════
-- DONE. Your database is ready.
-- Next step: copy your Project URL and anon key into index.html
-- ════════════════════════════════════════════════════════════════
