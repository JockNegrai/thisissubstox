# SubStox — Launch Guide
Everything you need to go from this folder to a live, paying product.

---

## STEP 1 — Set Up Supabase (your database + auth)

1. Go to https://supabase.com and click "Start your project" (free)
2. Sign up and create a new project — name it "substox", pick any region, set a password
3. Wait ~2 minutes for it to provision
4. Go to **SQL Editor** (left sidebar) → click **New Query**
5. Open the file `supabase_setup.sql` from this folder, copy ALL of it, paste it in, click **Run**
   - This creates all your tables and locks them down so users only see their own data
6. Go to **Settings → API** (left sidebar)
7. Copy two values:
   - **Project URL** (looks like `https://abcdef.supabase.co`)
   - **anon / public key** (long string starting with `eyJ...`)
8. Open `index.html` in a text editor, find these two lines near the top and paste your values:
   ```
   const SUPABASE_URL = 'PASTE_YOUR_PROJECT_URL_HERE';
   const SUPABASE_KEY = 'PASTE_YOUR_ANON_KEY_HERE';
   ```
9. Go to **Authentication → Providers** in Supabase → make sure **Email** is enabled (it is by default)
10. Optional: Go to **Authentication → Email Templates** and customize the confirmation email with your branding

---

## STEP 2 — Set Up Stripe (payments)

1. Go to https://stripe.com and create an account
2. Complete identity verification (required to receive payouts)
3. In the Stripe Dashboard, go to **Payment Links** → **+ New**
4. Create the **Starter plan** link:
   - Add product: "SubStox Starter" · $69/month · recurring
   - Enable "Don't collect a phone number"
   - Click Create — copy the link (looks like `https://buy.stripe.com/xxxxx`)
5. Create the **Growth plan** link:
   - Add product: "SubStox Growth" · $149/month · recurring
   - Copy the link
6. Set up the **Customer Portal** (lets customers cancel/upgrade themselves):
   - Go to **Settings → Billing → Customer Portal** → Activate
   - Copy the portal link
7. Open `index.html`, find these lines and paste your links:
   ```
   const STRIPE_STARTER = 'PASTE_STARTER_PAYMENT_LINK_HERE';
   const STRIPE_GROWTH  = 'PASTE_GROWTH_PAYMENT_LINK_HERE';
   const STRIPE_PORTAL  = 'PASTE_CUSTOMER_PORTAL_LINK_HERE';
   ```
8. In Stripe → **Settings → Customer Portal** → add the portal link to the user menu
   "Sign Out" button area in the app (optional, for self-serve cancellation)

---

## STEP 3 — Deploy to Vercel

1. Go to https://vercel.com and sign up (free)
2. Click **Add New → Project**
3. **Drag this entire `substox` folder** onto the Vercel deploy page
   - Must be the folder, not just index.html
4. Click **Deploy**
5. In ~15 seconds you get a live URL like `substox-abc123.vercel.app`
6. Test it — open the URL, click "Start Free Trial", make sure it goes to Stripe

---

## STEP 4 — Custom Domain (optional but looks professional)

1. Buy your domain at https://namecheap.com (e.g. `substox.com` ~$10/yr)
2. In Vercel → your project → **Domains** → type in your domain → Add
3. Vercel shows you DNS records to add (usually 2 records)
4. In Namecheap → **Domain List → Manage → Advanced DNS** → add those records
5. Wait 5–30 minutes → your domain is live

---

## STEP 5 — After Launch Checklist

- [ ] Test signup → Stripe payment → app login flow end to end
- [ ] Set up a support email (support@yourdomain.com) via Google Workspace ($6/mo)
  or free via Zoho Mail
- [ ] Add Google Analytics or Plausible to track visitors
  (paste the script tag just before `</head>` in index.html)
- [ ] Add Crisp live chat (crisp.chat — free) for customer support
  (paste their script tag before `</body>`)
- [ ] Set Stripe to email you on every new subscription (it does by default)
- [ ] Check Supabase → Authentication → Users after first signups to confirm it's working

---

## Revenue Projections

| Customers | Plan Mix        | MRR     |
|-----------|-----------------|---------|
| 10        | All Starter     | $690    |
| 10        | All Growth      | $1,490  |
| 20        | 50/50 mix       | $2,180  |
| 50        | 50/50 mix       | $5,450  |
| 100       | 50/50 mix       | $10,900 |

---

## Support

- Supabase docs: https://supabase.com/docs
- Stripe docs: https://stripe.com/docs
- Vercel docs: https://vercel.com/docs
